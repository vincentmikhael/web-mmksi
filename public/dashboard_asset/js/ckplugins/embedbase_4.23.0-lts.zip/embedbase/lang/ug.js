/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ug', {
	pathName: 'ۋاسىتە ئوبيېكتى',
	title: 'سىڭدۈرمە ۋاسىتە',
	button: 'سىڭدۈرمە ۋاسىتە قىستۇر',
	unsupportedUrlGiven: 'بەلگىلەنگەن ئۇلانمىنى قوللىمايدۇ .',
	unsupportedUrl: 'The URL {url} is not supported by Media Embed.', // MISSING
	fetchingFailedGiven: 'Failed to fetch content for the given URL.', // MISSING
	fetchingFailed: 'Failed to fetch content for {url}.', // MISSING
	fetchingOne: 'oEmbed نىڭ ئىنكاسىغا ئېرىشىۋاتىدۇ ...',
	fetchingMany: 'Fetching oEmbed responses, {current} of {max} done...' // MISSING
} );
