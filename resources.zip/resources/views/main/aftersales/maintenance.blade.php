@extends('layouts.main')

@section('content')
    {!!$maintenance->content!!}

@endsection
