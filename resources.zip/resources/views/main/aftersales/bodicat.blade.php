@extends('layouts.main')

@section('content')
<link rel="stylesheet" href="https://www.mitsubishi-motors.co.id/css/uikit.min.css">
<link rel="stylesheet" href="https://static.mitsubishi-motors.co.id/static/app.css?id=7ce75b842535b03f97940fdd2f744067">
<link rel="stylesheet" href="https://www.mitsubishi-motors.co.id/css/public.css">
<link rel="stylesheet" href="https://qiscus-sdk.s3-ap-southeast-1.amazonaws.com/public/qismo/qismo-v4.css">
<link rel="stylesheet" href="https://static.mitsubishi-motors.co.id/static/chatbot/widget.css?v=240711">

{!!$bodicat->content!!}
    

@endsection
